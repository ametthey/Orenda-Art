<p><?php _e( 'this is a message for users that are looking right now at the footer' , 'orenda_art' ); ?></p>
