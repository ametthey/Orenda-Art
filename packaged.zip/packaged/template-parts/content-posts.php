<?php
  /*
  * Template-parts calling for the Loop content
  */
?>

