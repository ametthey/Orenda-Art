<?php
    register_nav_menus( array(
        'header-menu'       => esc_html__( 'Menu du header', 'orenda_art' ),
        'header-menu-mobile'       => esc_html__( 'Menu du header mobile', 'orenda_art' ),
    ) );

?>
